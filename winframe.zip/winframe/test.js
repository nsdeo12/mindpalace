var array = [1, 2, 3, 4, 5, 6];
let intervals = 0;
console.log("interval==", intervals);


function calling() {
    if (intervals != 5) {
       
            console.log("ele:",array[intervals]);
            intervals+=1;
             
        setTimeout(calling, 1000);
    }
}
setTimeout(calling,2000)